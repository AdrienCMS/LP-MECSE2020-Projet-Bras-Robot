package com.example.projetbras6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private static SeekBar seekBarPouce;
    private static SeekBar seekBarIndex;
    private static SeekBar seekBarMajeur;
    private static SeekBar seekBarAnnulaire;
    private static SeekBar seekBarAuriculaire;

    private static TextView textViewPouce;
    private static TextView textViewIndex;
    private static TextView textViewMajeur;
    private static TextView textViewAnnulaire;
    private static TextView textViewAuriculaire;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureNextButton();
        configureMainsButton();
        seebbarr( );
    }

    private void configureNextButton () {
        Button boutonBras = (Button) findViewById(R.id.boutonBras);
        boutonBras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, BrasActivity.class));
            }
        });
    }

    private void configureMainsButton () {
        Button boutonMain = (Button) findViewById(R.id.boutonMain);
        boutonMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MouvementMainActivity.class));
            }
        });
    }

    public void seebbarr( ){
        seekBarPouce = (SeekBar)findViewById(R.id.seekBarPouce);
        seekBarIndex = (SeekBar)findViewById(R.id.seekBarIndex);
        seekBarMajeur = (SeekBar)findViewById(R.id.seekBarMajeur);
        seekBarAnnulaire = (SeekBar)findViewById(R.id.seekBarAnnulaire);
        seekBarAuriculaire = (SeekBar)findViewById(R.id.seekBarAuriculaire);

        textViewPouce =(TextView) findViewById(R.id.textViewPouce);
        textViewIndex =(TextView) findViewById(R.id.textViewIndex);
        textViewMajeur =(TextView) findViewById(R.id.textViewMajeur);
        textViewAnnulaire =(TextView) findViewById(R.id.textViewAnnulaire);
        textViewAuriculaire =(TextView) findViewById(R.id.textViewAuriculaire);

        textViewPouce.setText("" + seekBarPouce.getProgress() + "°" );
        textViewIndex.setText("" + seekBarIndex.getProgress() + "°" );
        textViewMajeur.setText("" + seekBarMajeur.getProgress() + "°" );
        textViewAnnulaire.setText("" + seekBarAnnulaire.getProgress() + "°" );
        textViewAuriculaire.setText("" + seekBarAuriculaire.getProgress() + "°" );

        seekBarPouce.setProgress(0);
        seekBarPouce.setMax(360);

        seekBarIndex.setProgress(0);
        seekBarIndex.setMax(360);

        seekBarMajeur.setProgress(0);
        seekBarMajeur.setMax(360);

        seekBarAnnulaire.setProgress(0);
        seekBarAnnulaire.setMax(360);

        seekBarAuriculaire.setProgress(0);
        seekBarAuriculaire.setMax(360);


        seekBarPouce.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        textViewPouce.setText("" + progress + "°");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );

        seekBarIndex.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        textViewIndex.setText("" + progress + "°");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );

        seekBarMajeur.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        textViewMajeur.setText("" + progress + "°");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );

        seekBarAnnulaire.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        textViewAnnulaire.setText("" + progress + "°");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );

        seekBarAuriculaire.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        textViewAuriculaire.setText("" + progress + "°");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );

    }
}
