package com.example.projetbras6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MouvementMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mouvement_main);

        configureBrasButton();
        configureDoigtsButton();
    }

    private void configureBrasButton () {
        Button boutonBras = (Button) findViewById(R.id.boutonBras);
        boutonBras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MouvementMainActivity.this, BrasActivity.class));
            }
        });
    }

    private void configureDoigtsButton () {
        Button boutonDoigts = (Button) findViewById(R.id.boutonDoigts);
        boutonDoigts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MouvementMainActivity.this, MainActivity.class));
            }
        });
    }
}
