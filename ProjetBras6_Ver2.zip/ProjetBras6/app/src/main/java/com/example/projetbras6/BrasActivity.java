package com.example.projetbras6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;


public class BrasActivity extends AppCompatActivity {
    public static SeekBar seekBarBras;

    public static TextView textBras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bras);

        configureNextButton();
        configureMainButton();
        seekbar();
    }
    private void configureNextButton () {
        Button boutonDoigts = (Button) findViewById(R.id.boutonDoigts);
        boutonDoigts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BrasActivity.this, MainActivity.class));
            }
        });
    }

    private void configureMainButton () {
        Button boutonMain = (Button) findViewById(R.id.boutonMain);
        boutonMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BrasActivity.this, MouvementMainActivity.class));
            }
        });
    }

    public void seekbar() {
        seekBarBras = (SeekBar)findViewById(R.id.seekBarBras);

        textBras =(TextView) findViewById(R.id.textBras);



    }
}
